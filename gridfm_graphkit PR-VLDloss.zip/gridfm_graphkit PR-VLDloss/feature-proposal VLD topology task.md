---
name: 🚀 Topology-based Voltage Loss Detection Task
about: Propose a new feature for inclusion in a future GridFM release to predict the bus ON/OFF status following a contigency and guide voltaes at failed buses to zero
title: "[Voltage loss prediction and network topology reconstruction] <Topology-based Voltage Loss Detection Task>"
labels: ["VLD-loss"]
assignees: "Mikka Kisuule "
---

## Summary
This features introduces a new Voltage Loss Detection (VLD) task and the associated model changes needed to integrate it.
The goal is to predict post-contingency bus energization status while preserving physically meaningful voltage outputs for buses that remain ON.

This task achieves prediction based load flow simulations in reliability analyses where network contingencies are simulated to identify the customers who are interrupted during each grid failure. 
This task also guides the model prediction to be topology-aware by guiding voltage predictions for ON buses towards the reconstructed voltage and towards zero for OFF buses.

The purpose of this task to GridFM users is to enforce topology-awareness during contigency analyses. 

---

## Motivation and Context

Explain the motivation behind this proposal.

- What use case(s) does this address?
- Is this driven by research, operational needs, or integration with external tools?
- Are there existing issues, discussions, or prototypes related to this?


The existing reconstruction stack is designed to recover physical power-flow quantities, but it does not explicitly model bus de-energization caused by network failures 
The VLD task addresses this gap by combining topology-aware supervision with standard physical prediction outputs.
This is useful when the model must distinguish between buses that remain energized and buses that should collapse to an off state after a contingency. It also reduces ambiguity in the training signal by making topology the primary driver of status prediction.

**Possible use-cases**: Reliability assessments, Contigency analysis 

**Drivers**: Acceleration of power flow simulations that involve multiple network contingencies. 
This is a key research concern as reliability analysis are computationally burdensome when dealing with large network and thousands of contingency scenarios. 

**Existing issues, discussions, prototypes**: Ongoing research has focused on optimising MCS-based reliability analysis for implementation on actual networks currently limited by computational requirements. 
When combined with MV and LV reliability equivalents, GridFM can enable the accurate reliability assessment of large MV/LV networks using probabilistic methods. 

**Link any relevant background material:** Ndawula, Mike Brian, et al. "A novel formulation of low voltage distribution network equivalents for reliability analysis." Sustainable Energy, Grids and Networks 39 (2024): 101437.

---

## Proposed Scope
The intended function of this task is to detect whether a bus survives a contingency while still producing usable physical outputs for the buses that remain active. 
The model is trained so that topology determines whether a bus can meaningfully carry voltage. 

**Core functionality:**
- Add a VLD-specific task that predicts bus status alongside standard physical outputs.
- Extend the model so the bus head returns physical outputs plus a status logit.
- Use a topology-first loss that treats reachability as the main supervision signal.
- Keep physically reachable buses close to their target Vm values.
- Force unreachable buses toward zero voltage.




**Optional extensions:**
- Add richer calibration metrics for bus status confidence.
- Support alternative topology-confidence weighting strategies.
- Add separate reporting for OFF-bus and ON-bus voltage errors.

**Explicitly excluded items:**
- Differentiable topology propagation.
- Changes to the core graph solver.
- New physics outside the existing branch-flow and nodal-balance framework.

---

## Target Release

Which release are you targeting?

- [ ] Next minor release (e.g., v0.X)
- [X] Future release (not the next one)
- [ ] Unsure / exploratory

If known, specify:

Target version: v0.X

> Note: Targeting a release does not guarantee inclusion; the feature must meet integration and quality criteria.

---

## Affected Components / Repositories

Which parts of GridFM will be impacted?

- [x] Core library
- [x] Models / architectures
- [x] Data pipelines
- [x] Training / evaluation code
- [x] Documentation
- [ ] Tooling / CI
- [ ] Other (please specify)

List specific repositories or modules if possible.
- ./datasets __init__.py, globals.py, powergrid_hetero_dataset.py, transforms.py, masking.py, task_transforms.py
- ./models __init__.py, gnn_heterogeneous_gns.py, utils.py (Physics encoders)
- ./tasks __init__.py, vld_task.py (Task implementation)
- ./training __init__.py, loss.py (Loss definition)
---

## Maturity Level

How mature is this feature today?

- [ ] Idea / design discussion
- [ ] Research prototype
- [X] Partially implemented
- [ ] Production‑ready

If a prototype exists, please link to code, papers, or branches.

---

## Dependencies and Risks


- The task depends on consistent feature indexing across datasets, transforms, losses, and model outputs.
- The topology loss depends on `latest_x_dict` being available during the forward pass.
- Branch pruning must remain consistent with contingency-specific `B_ON` handling.
- The status target layout must match the dataset’s bus target tensor exactly.
- Changes to `grid_path` behavior can accidentally overwrite topology state if not handled carefully.


---

## Breaking Changes

Does this feature introduce breaking changes?

- [X] No
- [ ] Yes (please describe)

---

## Testing and Validation Plan

How do you plan to validate this feature?

- Unit / integration tests - Unit tests for feature indices and tensor layouts and Integration tests for the VLD transform pipeline. 
Loss checks on topology target generation and Vm weighting. 
- Benchmarks: Accuracy compared to topology awareness of power flow solvers in reliability assessments
- Reproducibility checks: Evaluation of status accuracy, OFF-bus Vm collapse, and ON-bus Vm retention.
- Real‑world use cases: Distribution reliability assessment 

---

## Contribution Plan

- Primary contributor(s): Kisuule Mikka 
- Supervisor: Ignacio Hernando-Gil
- Organization: INESC TEC
- Expected level of maintainer support needed: Medium (available)

---

## Additional Notes

This task can be integrated into the Heterogeneous GridFM code stack to guide the prediction of the model's physical quantities with topology awareness. 